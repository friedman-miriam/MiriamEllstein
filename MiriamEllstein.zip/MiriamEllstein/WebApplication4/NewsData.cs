﻿namespace WebApplication4;

public class NewsData
{
    public string Title { get; set; }
    public string Body { get; set; }
    public string Link { get; set; }
    public int Index { get; set; }
}